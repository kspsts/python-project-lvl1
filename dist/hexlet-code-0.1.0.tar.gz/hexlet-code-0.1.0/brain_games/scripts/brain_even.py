from brain_games.brain_logic import game_logic

def main():
    game_logic()


if __name__ == '__main__':
    main()
