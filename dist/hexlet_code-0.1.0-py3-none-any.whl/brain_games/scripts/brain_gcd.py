from brain_games.gcd import game_logic

def main():
    game_logic()


if __name__ == '__main__':
    main()